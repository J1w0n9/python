#1번
a = 5
while a>=0:
    print("실행")
    a -= 1
print('정지!')
#2번
a = 4
while a >=0:
    print('안녕하세요')
    a-=1
#3번
n = int(input('n:'))
while n >= 1:
    print("실행")
    n-=1
#4번
n = int(input('n:'))
while n >= 0:
    print(n)
    n-=1
#5번
while 1:
    y = input("y 입력시 종료>")
    if y == "y":
        break
    print("y")