#1번
weight = 70
while(weight>60):
    print("운동하자")
    weight-=1
print("목표 달성!")
#2번
공사중 = "예"
while 공사중 == "예":
    print("공사중")
    공사중 = input("공사중입니까?(예/아니오)")
print("공사가 끝났네")
#3번
a = int(input('a:'))
while a >= 0:
    print('실행')
    a = int(input('a:'))
print('정지')