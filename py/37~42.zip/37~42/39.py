#1
alist = [11,22,33,44]
sum = 0
for num in alist:
    sum+=num
print(sum)

#2
a = ['사과', '바나나', '포도', '수박']
print(a[:2])
print(a[1:])
print(a[1:3])
print(a)